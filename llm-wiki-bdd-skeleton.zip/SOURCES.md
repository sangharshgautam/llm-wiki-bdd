# External Source References

# Uncomment and edit the paths below to point to your actual projects.
# The LLM will read from these paths instead of requiring copies in raw_sources/.
# For step_definitions, point to the project root directory — the LLM will
# recursively search for files with step definition markers.
# You can list multiple projects under golden_services. The LLM scans for *-test/ subdirectories.

step_definitions:
  - path: C:/Path/To/Your/StepDefinitionLibrary
    description: Your shared step definition library

golden_services:
  - path: C:/Path/To/Your/FirstProjectRoot
    description: First QA project (LLM scans *-test/ subdirs)
  #- path: C:/Path/To/Your/SecondProjectRoot
  #  description: Second QA project with different patterns

frontend_spec:
  - path: C:/Path/To/Your/NewApi/openapi.yaml
    description: New API spec to generate tests for

backend_spec:
  - path: C:/Path/To/Your/BackendApi/openapi.yaml
    description: Backend API spec to generate tests for
