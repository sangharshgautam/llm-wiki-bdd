# External Source References

# Uncomment and edit the paths below to point to your actual projects.
# The LLM will read from these paths instead of requiring copies in raw_sources/.
# For step_definitions, point to the project root directory - the LLM will
# recursively search for Java files with @Given/@When/@Then/@And annotations.
# You can list multiple projects under golden_features.

step_definitions:
  - path: C:/Path/To/Your/OpenapiBddProject
    description: Your shared step definition library

golden_features:
  - path: C:/Path/To/Your/FirstTestProject
    description: First QA test project
  #- path: C:/Path/To/Your/SecondTestProject
  #  description: Second QA test project with different patterns

new_specs:
  - path: C:/Path/To/Your/NewApi/openapi.yaml
    description: New API spec to generate tests for
