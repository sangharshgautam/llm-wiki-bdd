﻿# llm-wiki-bdd — Portable Skeleton

## Getting Started

1. Copy your Java step definition files into aw_sources/step_definitions/
2. Copy your existing QA-authored feature files + config into aw_sources/golden_features/<project-name>/
3. Copy the new OpenAPI spec into aw_sources/new_specs/
4. Tell your LLM: "Follow AGENTS.md. Ingest raw_sources/ into the wiki."

## Structure

| Directory | Purpose |
|---|---|
| aw_sources/ | Immutable source files - place your Java step defs, existing .feature files, and OpenAPI specs here |
| wiki/ | LLM-maintained knowledge base - auto-populated during ingest |
| generated/ | Output directory - the LLM will generate feature files and config here after your approval |
| AGENTS.md | The schema - tells the LLM how to maintain the wiki and generate tests |
