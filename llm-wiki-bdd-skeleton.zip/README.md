﻿# llm-wiki-bdd — Portable Skeleton

## Getting Started

1. Copy your step definition source files into `raw_sources/step_definitions/`
2. Copy your existing BDD feature files + config into `raw_sources/golden_services/<project-name>/` (the LLM scans for `*-test/` subdirectories)
3. Copy frontend API specs into `raw_sources/frontend_spec/` or backend API specs into `raw_sources/backend_spec/`
4. Tell your LLM: "Follow AGENTS.md. Ingest raw_sources/ into the wiki."

Alternatively, edit `SOURCES.md` with external paths instead of copying files.

## Structure

| Directory | Purpose |
|-----------|---------|
| `raw_sources/` | Immutable source files — place your step defs, service projects, and API specs here |
| `wiki/` | LLM-maintained knowledge base — auto-populated during ingest |
| `opencode.json` | Permission config — pre-authorizes writes to `wiki/` and `*-test/` dirs |
| `AGENTS.md` | The schema — tells the LLM how to maintain the wiki and generate tests |

Generated test projects are created in the current working directory as `<current-working-dir>/<api-name>-test/`,
mirroring the golden service layout.
