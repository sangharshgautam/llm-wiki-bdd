﻿# llm-wiki-bdd — Portable Skeleton

## How It Works

```
                                   ┌─────────────────────────────────────────────────────┐
                                   │                     INGEST PHASE                     │
                                   │  (run once per source; wiki compounds over time)     │
                                   └─────────────────────────────────────────────────────┘
                                                  │
                    ┌─────────────────────────────┼─────────────────────────────┐
                    │                             │                             │
                    ▼                             ▼                             ▼
    ┌───────────────────────────┐   ┌──────────────────────────────┐   ┌──────────────────┐
    │  Step Definition Source   │   │  Golden Service Projects     │   │  New Specs        │
    │  (Java @Given/@When/@Then)│   │  (feature files, config,     │   │  (frontend_spec,  │
    │  e.g. openapi-bdd         │   │   lifecycle, payloads)       │   │   backend_spec)   │
    └───────────┬───────────────┘   └──────────────┬───────────────┘   └────────┬─────────┘
                │                                  │                            │
                │ parse annotations                │ extract patterns           │ read fresh on
                │                                  │                            │ each generate
                ▼                                  ▼                            ▼
    ┌───────────────────────────┐   ┌──────────────────────────────┐   ┌──────────────────┐
    │  wiki/step_dictionary/    │   │  wiki/qa_patterns/           │   │  frontend spec   │
    │  (catalog of available    │   │  (scenario structure,        │   │  backend spec    │
    │   step expressions)       │   │   error patterns, payload    │   │                  │
    └───────────┬───────────────┘   │   conventions, lifecycle)    │   │  Parse schemas,  │
                │                  └──────────────┬───────────────┘   │  endpoints,      │
                │                                 │                   │  responses       │
                │                                 │                   └────────┬─────────┘
                ▼                                 ▼                            ▼
    ┌───────────────────────────┐   ┌──────────────────────────────────────────────────────┐
    │  Verify: every Gherkin    │   │                  GENERATE PHASE                       │
    │  step exists verbatim in  │   │                                                       │
    │  wiki/step_dictionary/    │   │  1. Reason about scenarios (Happy/Negative/Business)  │
    └───────────────────────────┘   │  2. Map each scenario to available steps from wiki    │
                                    │  3. Generate payloads & mocks per scenario tag        │
                                    │                                                       │
                                    │         For each scenario (H001, N001, B001, …):      │
                                    │         ┌────────────────────────────────────┐         │
                                    │         │ requestPayload/<TAG>.json          │         │
                                    │         │ responsePayload/<TAG>.json         │         │
                                    │         │ mocks/<TAG>.json                   │         │
                                    │         └────────────────────────────────────┘         │
                                    └──────────────────────────┬───────────────────────────┘
                                                               ▼
                                    ┌──────────────────────────────────────────────────────┐
                                    │              GENERATED OUTPUT                         │
                                    │  ┌─────────────────────────────────────────────┐     │
                                    │  │ journey-<api-name>-service-test/            │     │
                                    │  │ ├── pom.xml                                │     │
                                    │  │ ├── scenarios.md   (tabular doc)           │     │
                                    │  │ └── src/test/resources/                    │     │
                                    │  │     ├── features/                          │     │
                                    │  │     │   ├── happyPath.feature  (@H001,…)   │     │
                                    │  │     │   ├── negativePath.feature(@N001,…)  │     │
                                    │  │     │   └── businessScenarios.feature(@B…) │     │
                                    │  │     ├── requestPayload/ (H001.json, …)     │     │
                                    │  │     ├── responsePayload/(H001.json, …)     │     │
                                    │  │     └── mocks/        (H001.json, …)       │     │
                                    │  └─────────────────────────────────────────────┘     │
                                    └──────────────────────────────────────────────────────┘
```

## Getting Started

1. Copy your step definition source files into `raw_sources/step_definitions/`
2. Copy your existing BDD feature files + config into `raw_sources/golden_services/<project-name>/` (the LLM scans for `*-test/` subdirectories)
3. Copy frontend API specs into `raw_sources/frontend_spec/` or backend API specs into `raw_sources/backend_spec/`
4. Tell your LLM: "Follow AGENTS.md. Ingest raw_sources/ into the wiki."

Alternatively, edit `SOURCES.md` with external paths instead of copying files.

## Structure

| Directory | Purpose |
|-----------|---------|
| `raw_sources/` | Immutable source files — place your step defs, service projects, and API specs here |
| `wiki/` | LLM-maintained knowledge base — auto-populated during ingest |
| `opencode.json` | Permission config — pre-authorizes writes to `wiki/` and `*-test/` dirs |
| `AGENTS.md` | The schema — tells the LLM how to maintain the wiki and generate tests |

Generated test projects are created in the current working directory as `<current-working-dir>/journey-<api-name>-service-test/`,
mirroring the golden service layout.
